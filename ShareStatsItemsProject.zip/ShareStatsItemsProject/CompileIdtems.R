# Compile items

# install.packages("exams", dependencies = TRUE)
library("exams")

# Keep a record of the items you have compiled in this project
exams2html(file = "exampleProject/Descriptive_statistics/uva-test-en-001/uva-test-en-001.Rmd")
exams2html(file = "")
